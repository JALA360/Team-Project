document.addEventListener("DOMContentLoaded", () => {
    fetchGames();
});

function fetchGames() {
    fetch('http://www.trinity-developments.co.uk/games')
        .then(response => response.json())
        .then(data => {
            console.log(data);

            if (Array.isArray(data)) {
                renderGames(data);
            } else if (data.games && Array.isArray(data.games)) {
                renderGames(data.games);
            } else {
                console.error('Expected an array of games, but received:', data);
            }
        })
        .catch(error => console.error('Error fetching games data:', error));
}

function renderGames(games) {
    const gamesTableBody = document.getElementById("games-table").getElementsByTagName("tbody")[0];
    gamesTableBody.innerHTML = '';

    games.forEach(game => {
        const row = document.createElement("tr");

        const gameNameCell = document.createElement("td");
        gameNameCell.textContent = game.gameName;
        row.appendChild(gameNameCell);

        const mapCell = document.createElement("td");
        mapCell.textContent = game.mapName;
        row.appendChild(mapCell);

        const playersCell = document.createElement("td");
        playersCell.textContent = game.players.map(player => player.playerName).join(", ");
        row.appendChild(playersCell);

        const actionCell = document.createElement("td");
        const joinButton = document.createElement("button");
        joinButton.textContent = "Join";
        joinButton.onclick = () => joinGame(game.gameId);
        actionCell.appendChild(joinButton);
        row.appendChild(actionCell);

        gamesTableBody.appendChild(row);
    });
}

// Function to handle joining a game
function joinGame(gameId) {
    fetch(`http://www.trinity-developments.co.uk/games/${gameId}`)
        .then(response => response.json())
        .then(game => {
            displayGameDetails(game);
        })
        .catch(error => console.error('Error fetching game details:', error));
}

// Function to display details of the game
function displayGameDetails(game) {
    const gameDetails = document.createElement("div");
    gameDetails.innerHTML = `
        <h2>Game Details - ${game.gameName}</h2>
        <h3>Map: ${game.mapName}</h3>
        <img src="http://www.trinity-developments.co.uk/maps/${game.mapId}/map.png" alt="Map" />
        <h4>Players:</h4>
        <ul>
            ${game.players.map(player => `<li>${player.playerName}: ${player.currentLocation}</li>`).join('')}
        </ul>
    `;

    document.body.appendChild(gameDetails);
}